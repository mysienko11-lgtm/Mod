package com.cozyfurniture.client;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.entity.NoopRenderer;

import com.cozyfurniture.registry.ModEntities;

public class CozyFurnitureClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // The seat entity is invisible.
        EntityRenderers.register(ModEntities.SEAT, NoopRenderer::new);
    }
}
