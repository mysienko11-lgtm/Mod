package com.cozyfurniture.registry;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

import com.cozyfurniture.CozyFurniture;
import com.cozyfurniture.block.ChairBlock;
import com.cozyfurniture.block.StoolBlock;
import com.cozyfurniture.block.TableBlock;

public final class ModBlocks {
    /** Wood types; each needs textures minecraft:block/<wood>_planks. */
    public static final List<String> WOODS = List.of(
            "oak",
            "spruce",
            "birch",
            "jungle",
            "acacia",
            "dark_oak",
            "mangrove",
            "cherry",
            "pale_oak",
            "bamboo",
            "crimson",
            "warped"
    );

    public static final Map<String, Block> CHAIRS = new LinkedHashMap<>();
    public static final Map<String, Block> STOOLS = new LinkedHashMap<>();
    public static final Map<String, Block> TABLES = new LinkedHashMap<>();

    private ModBlocks() {}

    public static void init() {
        for (String wood : WOODS) {
            CHAIRS.put(wood, register(wood + "_chair", ChairBlock::new, props(wood)));
            STOOLS.put(wood, register(wood + "_stool", StoolBlock::new, props(wood)));
            TABLES.put(wood, register(wood + "_table", TableBlock::new, props(wood)));
        }
    }

    private static BlockBehaviour.Properties props(String wood) {
        SoundType sound = switch (wood) {
            case "bamboo" -> SoundType.BAMBOO_WOOD;
            case "cherry" -> SoundType.CHERRY_WOOD;
            case "crimson", "warped" -> SoundType.NETHER_WOOD;
            default -> SoundType.WOOD;
        };
        return BlockBehaviour.Properties.of()
                .strength(2.0F, 3.0F)
                .sound(sound)
                .noOcclusion();
    }

    private static Block register(String name,
                                  Function<BlockBehaviour.Properties, Block> factory,
                                  BlockBehaviour.Properties properties) {
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, CozyFurniture.id(name));
        Block block = factory.apply(properties.setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, CozyFurniture.id(name));
        BlockItem item = new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix());
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);
        return block;
    }
}
