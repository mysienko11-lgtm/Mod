package com.cozyfurniture.registry;

import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

import com.cozyfurniture.CozyFurniture;

public final class ModCreativeTabs {
    public static final ResourceKey<CreativeModeTab> FURNITURE_KEY =
            ResourceKey.create(Registries.CREATIVE_MODE_TAB, CozyFurniture.id("furniture"));

    private ModCreativeTabs() {}

    public static void init() {
        CreativeModeTab tab = FabricCreativeModeTab.builder()
                .icon(() -> new ItemStack(ModBlocks.CHAIRS.get("oak")))
                .title(Component.translatable("creativetab.cozyfurniture.furniture"))
                .displayItems((params, output) -> {
                    for (String wood : ModBlocks.WOODS) {
                        output.accept(ModBlocks.CHAIRS.get(wood));
                        output.accept(ModBlocks.STOOLS.get(wood));
                        output.accept(ModBlocks.TABLES.get(wood));
                    }
                })
                .build();
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, FURNITURE_KEY, tab);
    }
}
