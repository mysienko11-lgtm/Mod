package com.cozyfurniture.registry;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import com.cozyfurniture.CozyFurniture;
import com.cozyfurniture.entity.SeatEntity;

public final class ModEntities {
    private static final ResourceKey<EntityType<?>> SEAT_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, CozyFurniture.id("seat"));

    public static final EntityType<SeatEntity> SEAT = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            SEAT_KEY,
            EntityType.Builder.<SeatEntity>of(SeatEntity::new, MobCategory.MISC)
                    .sized(0.0F, 0.0F)
                    .noSave()
                    .clientTrackingRange(10)
                    .build(SEAT_KEY)
    );

    private ModEntities() {}

    /** Forces static initialization. */
    public static void init() {
    }
}
