package com.cozyfurniture.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;

import com.cozyfurniture.block.Sittable;
import com.cozyfurniture.registry.ModEntities;

/**
 * Invisible, non-saved entity the player rides while "sitting" on a chair or stool.
 * It removes itself when nobody rides it or when the furniture block is gone.
 */
public class SeatEntity extends Entity {
    private BlockPos seatPos;

    public SeatEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public void setSeatPos(BlockPos pos) {
        this.seatPos = pos;
    }

    public static InteractionResult sit(Level level, BlockPos pos, Player player, double seatHeight) {
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (player.isShiftKeyDown() || player.isPassenger()) {
            return InteractionResult.PASS;
        }
        // Somebody is already sitting here.
        if (!level.getEntitiesOfClass(SeatEntity.class, new AABB(pos)).isEmpty()) {
            return InteractionResult.SUCCESS;
        }

        SeatEntity seat = new SeatEntity(ModEntities.SEAT, level);
        seat.setSeatPos(pos);
        seat.setPos(pos.getX() + 0.5, pos.getY() + seatHeight, pos.getZ() + 0.5);
        level.addFreshEntity(seat);
        player.startRiding(seat);
        return InteractionResult.SUCCESS;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide()) {
            boolean empty = this.getPassengers().isEmpty();
            boolean gone = this.seatPos == null
                    || !(this.level().getBlockState(this.seatPos).getBlock() instanceof Sittable);
            if (empty || gone) {
                this.discard();
            }
        }
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        return false;
    }
}
