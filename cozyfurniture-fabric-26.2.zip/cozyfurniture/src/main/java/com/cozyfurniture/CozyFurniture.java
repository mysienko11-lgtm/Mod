package com.cozyfurniture;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cozyfurniture.registry.ModBlocks;
import com.cozyfurniture.registry.ModCreativeTabs;
import com.cozyfurniture.registry.ModEntities;

public class CozyFurniture implements ModInitializer {
    public static final String MOD_ID = "cozyfurniture";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModEntities.init();
        ModBlocks.init();
        ModCreativeTabs.init();
        LOGGER.info("Cozy Furniture loaded");
    }
}
