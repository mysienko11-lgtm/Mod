package com.cozyfurniture.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class TableBlock extends Block {
    // Keep in sync with the block model JSON.
    private static final VoxelShape SHAPE = ShapeUtil.of(new double[][] {
        {0, 14, 0, 16, 16, 16},
        {1, 0, 1, 3, 14, 3},
        {13, 0, 1, 15, 14, 3},
        {1, 0, 13, 3, 14, 15},
        {13, 0, 13, 15, 14, 15}
    });

    public TableBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }
}
