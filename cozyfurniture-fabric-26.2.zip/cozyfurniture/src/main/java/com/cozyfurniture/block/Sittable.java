package com.cozyfurniture.block;

/** Marker for blocks the player can sit on. */
public interface Sittable {
    /** Height (in blocks, from the bottom of the block) of the seat surface. */
    double seatHeight();
}
