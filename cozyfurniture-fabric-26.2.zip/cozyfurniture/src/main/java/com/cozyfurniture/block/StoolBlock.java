package com.cozyfurniture.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import com.cozyfurniture.entity.SeatEntity;

public class StoolBlock extends Block implements Sittable {
    // Keep in sync with the block model JSON.
    private static final VoxelShape SHAPE = ShapeUtil.of(new double[][] {
        {3, 0, 3, 5, 6, 5},
        {11, 0, 3, 13, 6, 5},
        {3, 0, 11, 5, 6, 13},
        {11, 0, 11, 13, 6, 13},
        {2, 6, 2, 14, 8, 14}
    });

    public StoolBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return SeatEntity.sit(level, pos, player, seatHeight());
    }

    @Override
    public double seatHeight() {
        return 0.5;
    }
}
