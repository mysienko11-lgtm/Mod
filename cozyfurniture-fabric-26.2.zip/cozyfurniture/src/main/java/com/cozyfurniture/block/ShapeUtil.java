package com.cozyfurniture.block;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class ShapeUtil {
    private ShapeUtil() {}

    /**
     * Builds a shape from boxes (0..16 model space) that were authored for a NORTH-facing block,
     * rotated clockwise (seen from above) to match the given facing.
     */
    public static VoxelShape rotated(Direction facing, double[][] boxes) {
        int turns = switch (facing) {
            case EAST -> 1;
            case SOUTH -> 2;
            case WEST -> 3;
            default -> 0;
        };
        VoxelShape shape = Shapes.empty();
        for (double[] b : boxes) {
            double x1 = b[0], y1 = b[1], z1 = b[2], x2 = b[3], y2 = b[4], z2 = b[5];
            for (int i = 0; i < turns; i++) {
                double nx1 = 16 - z2;
                double nx2 = 16 - z1;
                double nz1 = x1;
                double nz2 = x2;
                x1 = nx1;
                x2 = nx2;
                z1 = nz1;
                z2 = nz2;
            }
            shape = Shapes.or(shape, Block.box(x1, y1, z1, x2, y2, z2));
        }
        return shape;
    }

    public static VoxelShape of(double[][] boxes) {
        return rotated(Direction.NORTH, boxes);
    }
}
