# Cozy Furniture — мод на меблі (Fabric, Minecraft 26.2)

Стільці, табурети й столи з 12 видів дерева (36 блоків). На стільцях і табуретах можна сидіти
(ПКМ порожньою рукою; з Shift — не сідати, а ставити блок).

## Вимоги
- JDK 25
- IntelliJ IDEA 2025.3+ (або будь-яка IDE з Gradle)
- Minecraft 26.2, Fabric Loader 0.19.3+, Fabric API 0.152+

## Збірка
1. Якщо немає `gradlew` / `gradle/wrapper/gradle-wrapper.jar`, візьміть їх із шаблону
   https://fabricmc.net/develop/template/ (або виконайте `gradle wrapper --gradle-version 9.5.1`).
2. `./gradlew build` — готовий `.jar` буде в `build/libs/cozyfurniture-1.0.0.jar`.
3. Запуск для тесту: `./gradlew runClient`.
4. Покладіть `.jar` у папку `mods` разом із Fabric API.

## Збірка без локального налаштування (GitHub)
Завантажте проєкт у свій репозиторій на GitHub — вкладка **Actions → build** збере `.jar`
(файл `cozyfurniture-jar` у розділі Artifacts). Gradle wrapper для цього не потрібен.

## Структура
- `block/` — ChairBlock, StoolBlock, TableBlock (форми колізії задані боксами)
- `entity/SeatEntity` — невидима сутність, на якій «сидить» гравець
- `registry/` — реєстрація блоків, сутності та креатив-вкладки
- `src/main/resources/assets/cozyfurniture/` — моделі, стани блоків, мови (en_us, uk_ua)
- `src/main/resources/data/cozyfurniture/` — рецепти та луттейбли

## Налаштування
- Висота сидіння: `seatHeight()` у ChairBlock / StoolBlock (зараз 0.5). Якщо гравець «провалюється» чи «висить» — змініть.
- Нове дерево: додайте його id в `ModBlocks.WOODS` і створіть JSON-файли (моделі, blockstate, item, loot, recipe, lang) —
  або скористайтеся скриптом-генератором.
- Текстури беруться з ванільних дощок (`minecraft:block/<дерево>_planks`). Щоб мати свої — покладіть png в
  `assets/cozyfurniture/textures/block/` і змініть шляхи в моделях.
- Якщо змінюєте форму моделі — оновіть відповідні `BOXES` у Java, щоб колізія збігалася.
